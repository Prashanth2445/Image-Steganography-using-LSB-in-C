/*
NAME: PRASHANTH REDDY
BATCH: 25021A
DATE: 27-10-2025
DESCRIPTION: This program is about a Steganography project using BMP images.
             It can encode a secret text file into a BMP image by modifying the LSB (Least Significant Bit) of image pixels.
             The program can decode the hidden text from the stego BMP image back to a readable text file.
             It can encode and decode magic strings to verify the presence of secret data.
             It supports hiding the secret file name extension and size along with the content.
             The program is implemented using file handling, structures, functions, pointers, and bitwise operations in C.
             Command prompt messages indicate the process:
*/

#include <stdio.h>
#include "encode.h"
#include <string.h>
#include "types.h"
#include <stdlib.h>

#include "decode.h"

int main(int argc, char *argv[])
{
    if (check_operation_type(argv) == e_encode) // check choice encoding or decoding function call
    {
        printf("------------------------------------\n");
        printf("|::  You have choosed encodeing  ::|\n");
        printf("------------------------------------\n");

        if (argv[2] == NULL)
        {
            printf("Invalid, please pass the valid arguments (file names)\nbeautiful.bmp secret.txt is compulsory\n");
            exit(1);
            return e_failure;
        }

        EncodeInfo encInfo; // structure variable declaration
        printf("Enter the magic string: ");
        scanf("%s", encInfo.ch_buf);

        if (read_and_validate_encode_args(argv, &encInfo) == e_success) // read & validate encode args function call in if condition
        {
            printf("Read and Validate is successfully\n");
            if (do_encoding(&encInfo) == e_success)
            {
                printf("------------------------------\n");
                printf("|::  Encoding successfull  ::|\n");
                printf("------------------------------\n");
            }
            else
            {
                printf("Encoding unsuccessfull\n");
            }
        }
        else
        {
            printf("Reda and validate is unsuccessfull\n");
            return e_failure;
        }
    }
    else if (check_operation_type(argv) == e_decode) // check choice encoding or decoding function call
    {
        printf("------------------------------------\n");
        printf("|::  You have choosed decodeing  ::|\n");
        printf("------------------------------------\n");
        DecodeInfo decInfo;
        if (read_and_validate_decode_args(argv, &decInfo) == e_success)
        {
            printf("Read and Validate is successfully\n");
            if (do_decoding(&decInfo) == e_success)
            {
                printf("-------------------------------\n");
                printf("|::  Decoding unsuccessfull  ::|\n");
                printf("-------------------------------\n");
            }
            else
            {
                printf("Decoding unsuccessfull\n");
            }
        }
    }
    else
    {
        printf("It is unsupported\n");
        return e_failure;
    }
    return e_success;
}

OperationType check_operation_type(char *argv[])
{
    if (argv[1] == NULL)
    {
        printf("Invalid, please pass the valid argument\n'-e' for encoding, '-d' for decoding is compulsory\n");
        exit(1);
        return e_failure;
    }
    if (strcmp(argv[1], "-e") == 0)
    {
        return e_encode;
    }
    else if (strcmp(argv[1], "-d") == 0)
    {
        return e_decode;
    }
    else
    {
        // printf("Invalid, please pass the valid arguments (file names)\nbeautiful.bmp secret.txt is compulsory\n");
        // exit(1);
        return e_unsupported;
    }
}