#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "types.h"
#include "encode.h"
#include "common.h"

// chech the all files are valid the there extension
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    if (argv[2] == NULL)
    {
        printf("Invalid, please pass the valid arguments (file names)\nbeautiful.bmp secret.txt is compulsory\n");
        exit(1);
        return e_failure;
    }
    // check in cmd beautifull.bmp file is present or not
    if (strstr(argv[2], ".bmp") != NULL)
    {
        printf("Beautifull.bmp is present\n");
        encInfo->src_image_fname = argv[2];
    }
    else
    {
        printf("Beautifull.bmp is not present\n");
        return e_failure;
    }

    // check in cmd .txt file is present or not
    if (strstr(argv[3], ".txt") != NULL)
    {
        printf("Secret.txt is present\n");
        encInfo->secret_fname = argv[3];
    }
    else
    {
        printf("Secret.txt is not present\n");
        return e_failure;
    }

    // check in cmd stego.bmp file is present or not, if not create by default
    if (argv[4] != NULL)
    {
        if (strstr(argv[4], ".bmp") != NULL)
        {
            printf("stego.bmp is present\n");
            encInfo->stego_image_fname = argv[4];
        }
        else
        {
            printf("stego.bmp is not present, Creating default.bmp by default\n");

            // creating by default stego file

            encInfo->fptr_stego_image = fopen("default.bmp", "wb");
            encInfo->stego_image_fname = "default.bmp";
            if (encInfo->fptr_stego_image == NULL)
            {
                printf("Stego file is failed to create\n");
                return e_failure;
            }
            else
            {
                printf("Stego file is created successfully\n");
            }
        }
    }
    else if (argv[4] == NULL)
    {
        printf("Stego.bmp is not present, Creating default.bmp by default\n");

        // creating by default stego file

        encInfo->fptr_stego_image = fopen("default.bmp", "wb");
        encInfo->stego_image_fname = "default.bmp";
        if (encInfo->fptr_stego_image == NULL)
        {
            printf("Stego file is failed to create\n");
            return e_failure;
        }
        else
        {
            printf("Stego file is created successfully\n");
        }
    }
    return e_success; // if all files are present
}

// start doing encoding
Status do_encoding(EncodeInfo *encInfo)
{
    printf("-------------------------\n");
    printf("|::  Started Encoding ::|\n");
    printf("-------------------------\n");
    if (open_files(encInfo) == e_success) // open all files
    {
        printf("All files are opened successfully\n");
        if (check_capacity(encInfo) == e_success) // check the capacity of bmp file can store all the data ?
        {
            printf("The .bmp file have enough capacity to store\n");
            if (encInfo->fptr_src_image == NULL || encInfo->fptr_stego_image == NULL) // if src and stego files are opened are not
            {
                printf("Error: File pointers not initialized properly.\n");
                return e_failure;
            }
            if (copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success) // copy bmp header function call
            {
                printf("Copying the header file\nDone\n");
                if (encode_magic_string_size(encInfo->ch_buf, encInfo) == e_success) // encoding magic string size function call
                {
                    printf("Encoded magic string size\nDone\n");
                    if (encode_magic_string(encInfo->ch_buf, encInfo) == e_success) // magic string encoding function call
                    {
                        printf("Encoding magic string\nDone\n");
                        if (encode_secret_file_extn_size(strstr(encInfo->secret_fname, ".txt"), encInfo) == e_success) // encoding secret file extn (size of extn {.txt}==4)
                        {
                            printf("Encoded the secret file extn size\nDone\n");
                            if (encode_secret_file_extn(strstr(encInfo->secret_fname, ".txt"), encInfo) == e_success) // encode secret file ectension size
                            {
                                printf("Encoded secret file extn\nDone\n");
                                if (encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_success) // encoding secret file size
                                {
                                    printf("Encoded secret file size\nDone\n");
                                    if (encode_secret_file_data(encInfo) == e_success) // Status encode_secret_file_data(EncodeInfo *encInfo);
                                    {
                                        printf("Encoded secret file data\nDone\n");
                                        if (copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success) // copy the remaining data
                                        {
                                            printf("Encoding remaining data\nDone\n");
                                        }
                                        else
                                        {
                                            printf("Failed to encode remaining image data\n");
                                            return e_failure;
                                        }
                                    }
                                    else
                                    {
                                        printf("Failed to encode secret file\n");
                                        return e_failure;
                                    }
                                }
                                else
                                {
                                    printf("Failed to encode secret file size\n");
                                    return e_failure;
                                }
                            }
                            else
                            {
                                printf("Failed to encode secret file extn\n");
                                return e_failure;
                            }
                        }
                        else
                        {
                            printf("Failed to encode secret file size\n");
                            return e_failure;
                        }
                    }
                    else
                    {
                        printf("Failed to Encode magic string\n");
                        return e_failure;
                    }
                }
                else
                {
                    printf("Failed to Encode magic string size\n");
                    return e_failure;
                }
            }
            else
            {
                printf("Failed to copy .bmp file header\n");
                return e_failure;
            }
        }
        else
        {
            printf("The file size is not capable for encoding\n");
            return e_failure;
        }
    }
    else
    {
        printf("Files are not open successfully\n");
        return e_failure;
    }
    return e_success;
}
Status open_files(EncodeInfo *encInfo) // opening file function defination
{
    // Open Source file in read mode
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "rb");

    if (encInfo->fptr_src_image == NULL)
    {
        printf("Source file is not present\n");
        return e_failure;
    }
    else
    {
        printf("Source file is opened\n");
    }

    // Open secret  file in read mode
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "rb");

    if (encInfo->fptr_secret == NULL)
    {
        printf("Secret file is not present,\n");
        return e_failure;
    }
    else
    {
        printf("Secret file is opened\n");
    }

    // open stegno.bmp file in write mode

    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "wb"); // before only created file for that commanted

    if (encInfo->fptr_stego_image == NULL)
    {
        printf("Stego file is not present\n");
        return e_failure;
    }
    else
    {
        printf("stego file is opened\n");
    }

    return e_success; // if all files are opend
}
/* Check the capacity of source file for encode the data */
Status check_capacity(EncodeInfo *encInfo) // check capacity function
{
    uint width, height; // temp variables

    fseek(encInfo->fptr_src_image, 18, SEEK_SET); // move file pointer at 18th position

    fread(&width, sizeof(uint), 1, encInfo->fptr_src_image); // read 4 bytes for width

    fread(&height, sizeof(uint), 1, encInfo->fptr_src_image); // read 4 bytes for hight

    encInfo->image_capacity = width * height * 3; // calculating image capacity

    fseek(encInfo->fptr_secret, 0, SEEK_END); // moving file pointer to starting position

    encInfo->size_secret_file = ftell(encInfo->fptr_secret);

    // check capacity and return
    if (encInfo->image_capacity > 54 + (2 * 4 * 4 * 4 * (encInfo->size_secret_file)) * 8) // check capacity
    {

        return e_success;
    }
    else
    {
        return e_failure;
    }

    // rewind(encInfo->fptr_src_image); // same as
    fseek(encInfo->fptr_src_image, 0, SEEK_SET); // move file pointer to starting
}

// Copy .bmp file header src to dest
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char buffer[54];
    fseek(fptr_src_image, 0, SEEK_SET);

    fread(buffer, 54, 1, fptr_src_image);

    fwrite(buffer, 54, 1, fptr_stego_image);

    fseek(fptr_stego_image, 54, SEEK_SET);
    return e_success;
}

// encoding the magic string
Status encode_magic_string(char *magic_string, EncodeInfo *encInfo)
{
    // printf("len %ld",strlen(magic_string));
    if (encode_data_to_image(magic_string, strlen(magic_string), encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success) // data to image function call
    {
        return e_success;
    }
}

// encode magic string function
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char arr[8];

    for (int i = 0; i < size; i++)
    {
        fread(arr, 8, 1, fptr_src_image);
        // printf("data i %c\n",data[i]);
        if (encode_byte_to_lsb(data[i], arr) == e_success) // byte to lsb function call
        {
            fwrite(arr, 8, 1, fptr_stego_image);
        }
    }

    return e_success;
}

// real encoding function
Status encode_byte_to_lsb(char data, char *arr)
{
    for (int i = 0; i < 8; i++)
    {
        // printf("binary %d %d\n",i,arr[i]);
        arr[i] &= ~1;                    // Clear LSB
        arr[i] |= (data >> (7 - i)) & 1; // Extract bit from data (MSB first)
        // printf("binary 2 %d\n",arr[i]);
    }
    return e_success;
}

// encoding secret file extn size
Status encode_secret_file_extn_size(const char *file_extn, EncodeInfo *encInfo)
{

    encInfo->size_secret_file_extn = strlen(file_extn); // secret file extension size  strlen

    // printf("size %d\n",encInfo->size_secret_file_extn);

    fread(encInfo->arr1, 32, 1, encInfo->fptr_src_image);

    encode_size_to_lsb(encInfo->size_secret_file_extn, encInfo->arr1); /// size to lsb function call

    fwrite(encInfo->arr1, 32, 1, encInfo->fptr_stego_image);

    return e_success;
}

// encoding size to lsb,
Status encode_size_to_lsb(unsigned int data, unsigned char arr[])
{
    for (int i = 0; i < 32; i++)
    {
        // printf("binary %d %d\t",i,arr[i]);
        arr[i] &= 0xFE;                     // Clear LSB
        arr[i] |= ((data >> (31 - i)) & 1); // Extract bit from data (MSB first)
        // printf("binary 2 %d\n",arr[i]);
    }
    return e_success;
}

/*Encode the secret file extension */
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    // printf("extn= %s\n",file_extn);
    for (int i = 0; i < strlen(file_extn); i++)
    {
        fread(encInfo->ch_buf, 8, 1, encInfo->fptr_src_image);

        encode_byte_to_lsb(file_extn[i], encInfo->ch_buf);

        fwrite(encInfo->ch_buf, 8, 1, encInfo->fptr_stego_image);
    }
    return e_success;
}

/*Encode secret file size */
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    // printf("extn= %ld\n",file_size);
    fread(encInfo->arr1, 32, 1, encInfo->fptr_src_image);

    encode_size_to_lsb(file_size, encInfo->arr1);

    fwrite(encInfo->arr1, 32, 1, encInfo->fptr_stego_image);
    return e_success;
}

/* Encode the secret file data */
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "rb");

    char ch;
    for (int i = 0; i < encInfo->size_secret_file; i++)
    {
        if (fread(&ch, 1, 1, encInfo->fptr_secret) != 1)
        {
            printf("Error reading secret file at byte %d\n", i);
            break;
        }
        // printf("Encoding char #%d = '%c' (%d)\n", i, ch, ch);

        // fread(&ch, 1, 1, encInfo->fptr_secret);
        fread(encInfo->image_data, 8, 1, encInfo->fptr_src_image);

        encode_byte_to_lsb(ch, encInfo->image_data);

        fwrite(encInfo->image_data, 8, 1, encInfo->fptr_stego_image);
    }
    return e_success;
}

/* copy the remaining data */
Status copy_remaining_img_data(FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char ch;
    while (fread(&ch, 1, 1, fptr_src_image) == 1)
    {
        fwrite(&ch, 1, 1, fptr_stego_image);
    }
    return e_success;
}

// Magic string size encoding
Status encode_magic_string_size(char *magic, EncodeInfo *encInfo)
{
    // printf("Encoded magic size: %lu\n", strlen(magic));

    fread(encInfo->arr1, 32, 1, encInfo->fptr_src_image);

    encode_size_to_lsb(strlen(magic), encInfo->arr1);

    fwrite(encInfo->arr1, 32, 1, encInfo->fptr_stego_image);

    return e_success;
}