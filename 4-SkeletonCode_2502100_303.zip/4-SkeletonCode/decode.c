#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "types.h"
#include "decode.h"
#include "common.h"

/*Read and validate the decoding argivements*/
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    if (argv[2] == NULL)
    {
        printf("Invalid, please pass the valid arguments (file names)\nstego.bmp is compulsory\n");
        exit(1);
        return e_failure;
    }
    // check in cmd beautifull.bmp file is present or not
    if (strstr(argv[2], ".bmp") != NULL)
    {
        printf("Stego.bmp is present\n");
        decInfo->stego_image_fname = argv[2];
    }
    else
    {
        printf("Stego.bmp is not present\n");
        return e_failure;
    }

    /*check output.txt file is present or not if not create by default*/
    if (argv[3] == NULL)
    {
        printf("Output.txt is not present\n");
        printf("Output file is creating by default\n");
        decInfo->fptr_out_image = fopen("Default.txt", "wb");
        decInfo->out_image_fname = "Default.txt";
        decInfo->out_fname = "Default.txt";
    }

    else if (strstr(argv[3], ".txt") != NULL)
    {
        // printf("Output file is creating by default\n");
        printf("Output.txt is present\n");
        decInfo->out_image_fname = argv[3];
        decInfo->out_fname = argv[3];
    }
    else
    {
        printf("Failed to create a output.txt file\n");
        return e_failure;
    }
    return e_success;
}

/*open the files stego.bmp output.txt*/
Status open_files_decoding(DecodeInfo *decInfo)
{
    // Open Stego file in read mode
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "rb");

    // printf("stego file name %s\n",decInfo->stego_image_fname);
    if (decInfo->fptr_stego_image == NULL)
    {
        printf("Stego file is not present\n");
        return e_failure;
    }
    else
    {
        printf("Stego file is opened\n");
    }

    // Open output  file in write mode
    decInfo->fptr_out_image = fopen(decInfo->out_image_fname, "wb");

    if (decInfo->fptr_out_image == NULL)
    {
        printf("Output file is not present,\n");
        return e_failure;
    }
    else
    {
        printf("Output file is opened\n");
    }

    return e_success; // if all files are opend
}

/*Start doing decoding*/
Status do_decoding(DecodeInfo *decInfo)
{
    // printf("Decoding started\n");
    if (open_files_decoding(decInfo) == e_success) // open files function call
    {
        printf("All files are opened successfully\n");

        if (decode_magic_string_size(decInfo->ch_buf, decInfo) == e_success) // decode magic string size function call
        {
            printf("Decoded Magic String Size = %u\n", decInfo->magic_string_size);
            if (decode_magic_string(decInfo->ch_buf, decInfo->magic_string_size, decInfo) == e_success) // decode magic string function call
            {
                printf("Magic string: %s\n", decInfo->data);
                printf("Done\n");
                if (decode_secret_file_extn_size(decInfo) == e_success) // decode secret file extension size function call
                {
                    printf("Done\n");
                    if (decode_secret_file_extn(decInfo->size_secret_file_extn, decInfo) == e_success) // decode secret file extension function call
                    {
                        printf("Decoded secret file size extension: %s\n", decInfo->data);
                        printf("Done\n");

                        if (check_output_file_extension(decInfo) == e_success)
                        {

                            if (decode_secret_file_size(decInfo->size_secret_file, decInfo) == e_success) // decode secret file size function call
                            {
                                printf("Done\n");
                                if (decode_secret_file_data(decInfo->size_secret_file, decInfo) == e_success) // Decode secret data function call
                                {
                                    printf("Decoded secret data: %s\n", decInfo->data);
                                    // printf("Decoded successfully done\n");
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return e_success;
}

/* Decode magic string size */
Status decode_magic_string_size(char *magic_string, DecodeInfo *decInfo)
{

    fseek(decInfo->fptr_stego_image, 54, SEEK_SET); // fseekset to 54 byte

    fread(decInfo->arr1, 1, 32, decInfo->fptr_stego_image); // read 32 byte from stego.bmp file

    decInfo->magic_string_size = decode_size_to_lsb(decInfo->arr1);

    // printf("Decoded Magic String Size = %u\n", decInfo->magic_string_size);
    return e_success;
}

/*decode size from lsb*/
unsigned int decode_size_to_lsb(unsigned char buffer[])
{
    unsigned int size = 0;
    for (int i = 0; i < 32; i++)
    {
        size = (size << 1) | (buffer[i] & 1); // decode size from lsb
    }
    return size;
}

/* Decode a magic string */
Status decode_magic_string(char *magic_string, unsigned int size, DecodeInfo *decInfo)
{
    // char decode_ch;
    for (int i = 0; i < size; i++)
    {
        fread(decInfo->ch_buf, 1, 8, decInfo->fptr_stego_image);
        decInfo->decode_ch = decode_byte_to_lsb(decInfo->ch_buf, decInfo);
        decInfo->data[i] = decInfo->decode_ch;
    }
    decInfo->data[size] = '\0';
    return e_success;
}

/*Decode byte from lsb */
char decode_byte_to_lsb(char *arr, DecodeInfo *decInfo)
{

    unsigned char data = 0; //  temp unsigned char
    for (int i = 0; i < 8; i++)
    {
        data = (data << 1) | (arr[i] & 1); // decode size from lsb
    }

    return data;
}

Status decode_secret_file_extn_size(DecodeInfo *decInfo)
{
    fread(decInfo->arr1, 1, 32, decInfo->fptr_stego_image); // read 32 byte from stego.bmp file
    decInfo->size_secret_file_extn = decode_size_to_lsb(decInfo->arr1);
    printf("Decoded size of secret file extension: %u\n", decInfo->size_secret_file_extn);
    return e_success;
}
Status decode_secret_file_extn(int size, DecodeInfo *decInfo)
{
    // printf("Decoded secret file size extension: ");
    for (int i = 0; i < size; i++)
    {
        fread(decInfo->ch_buf, 1, 8, decInfo->fptr_stego_image);
        decInfo->decode_ch = decode_byte_to_lsb(decInfo->ch_buf, decInfo);
        decInfo->data[i] = decInfo->decode_ch;
    }
    decInfo->data[size] = '\0';

    // printf("\n");
    return e_success;
}
Status decode_secret_file_size(unsigned int file_size, DecodeInfo *decInfo)
{
    fread(decInfo->arr1, 1, 32, decInfo->fptr_stego_image); // read 32 byte from stego.bmp file
    decInfo->size_secret_file = decode_size_to_lsb(decInfo->arr1);
    printf("Decoded secret file size: %u\n", decInfo->size_secret_file);
    return e_success;
}

Status decode_secret_file_data(unsigned int size, DecodeInfo *decInfo)
{
    // printf("File pointer before decoding X = %ld\n", ftell(decInfo->fptr_stego_image));

    char ch;
    // printf("Decoded secret data: ");
    for (int i = 0; i < size; i++)
    {
        fread(decInfo->ch_buf, 1, 8, decInfo->fptr_stego_image);
        ch = decode_byte_to_lsb(decInfo->ch_buf, decInfo);
        fputc(ch, decInfo->fptr_out_image);
        decInfo->data[i] = ch;
    }
    decInfo->data[size] = '\0';

    // printf("File pointer before decoding X = %ld\n", ftell(decInfo->fptr_stego_image));

    return e_success;
}

/*checking extension*/
Status check_output_file_extension(DecodeInfo *decInfo)
{

    if (decInfo->out_fname == NULL)
    {
        printf("Output filename is NULL.\n");
        return e_failure;
    }

    // printf("Output filename from main: %s\n", decInfo->out_fname);

    int len = strlen(decInfo->out_fname);

    // If filename is too short to contain ".txt"
    if (len < 4)
    {
        printf("Output filename too short to have an extension.\n");
        return e_failure;
    }

    // Compare last 4 characters with ".txt"
    if (strcmp(decInfo->out_fname + (len - 4), ".txt") == 0)
    {
        printf("Output filename has .txt extension \n");
        return e_success;
    }
    else
    {
        printf("Output filename does not have .txt extension \n");
        return e_failure;
    }
}
